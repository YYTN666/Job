import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MyService } from './service/my.service';
import { MyData } from './service/my.data';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-root',  // Selector for this component
  standalone: true,
  imports: [RouterOutlet, FormsModule, CommonModule, HttpClientModule],
  templateUrl: './app.component.html',  // Path to the HTML template file
  styleUrls: ['./app.component.css'],  // Path to the CSS file for styles
  providers: [MyService]  // Register MyService as a provider for dependency injection
})
export class AppComponent {
  public title: string = 'httpservapp';  // Title of the application
  public book: MyData = new MyData(0, '', '', 0);  // Instance to hold new book data for adding
  public name: string = '';  // Variable to hold the name of the book for searching
  public deleteId: number = 0;  // Variable to hold the ID of the book for deletion
  public all_records: any;  // To store all the book records retrieved from the service
  public message: string = '';  // Message variable to display success/error messages to the user
  public parse_all_records: any = 0;
  public shown: boolean = true;

  constructor(private service: MyService) { }  // Inject MyService into the component

  // Method to fetch all book data from the service
  readAlldata() {
    this.shown = true;
    this.service.getAllData().subscribe({
      next: (data) => {
        this.all_records =data;;  // Store the fetched data in the all_records array
        this.message = 'Books retrieved successfully';  // Set success message
        this.parse_all_records = JSON.parse(this.all_records);
        console.log(data);
      },
      error: (err: any) => {
        console.log(err);  // Log errors to the console
        this.message = 'Error retrieving books';  // Set error message
      }
    });
  }

  // Method to fetch a single book data based on the provided name
  readOnedata() {
    this.service.getOneData(this.name).subscribe({
      next: (data: MyData[]) => {
        if (data.length > 0) {
          this.all_records = data;  // Assign fetched data to the records array
          this.message = 'Book found! ' + data;  // Set success message
        } else {
          this.message = 'No book found';  // Set message if no book is found
        }
      },
      error: (err: any) => {
        console.log(err);  // Log any errors to the console
        this.message = 'Error retrieving book';  // Set error message
      }
    });
  }

  // Method to add a new book to the database
  adddata() {
    this.service.addData(this.book).subscribe({
      next: (data: MyData) => {
        this.message = 'Book successfully added';  // Set success message
        this.book = new MyData(0, '', '', 0);  // Clear input fields after addition
        this.readAlldata(); // Refresh the book list after deletion
      },
      error: (err: any) => {
        console.log(err);  // Log any errors
        this.message = 'Error adding book';  // Set error message
        this.book = new MyData(0, '', '', 0);
      }
    });
  }

  // Method to delete a book based on the ID provided
  deletedata() {
    if (this.deleteId) {  // Ensure deleteId is not undefined or null
      this.service.deleteData(this.deleteId).subscribe({
        next: (data: MyData) => {
          this.message = 'Book successfully deleted';  // Set success message
          this.readAlldata();  // Refresh the book list after deletion
        },
        error: (err: any) => {
          console.log(err);  // Log errors
          this.message = 'Error deleting book';  // Set error message
        }
      });
    } else {
      this.message = 'Please enter a valid book ID.'; // Prompt for valid ID if empty
    }
  }

  visibility() {
    this.shown = false; // Change visibility
    this.message = 'Hide successfully'; 
  }
}



