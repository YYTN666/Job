import { MyData } from "./my.data";
import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable()
export class MyService {
  private url: string = "https://nlon43ublb.execute-api.us-east-1.amazonaws.com/yutaien_stage";

  constructor(private http: HttpClient) { }

  // Method to get all data
  public getAllData(): Observable<MyData[]> {
    return this.http.get<MyData[]>(this.url + '?param=all'); // Using string concatenation for URL
  }

  // Method to add new book data using GET
  public addData(book: MyData): Observable<any> {
    return this.http.get<any>(this.url + '?param=' + book.id + ',' + book.name + ',' + book.author + ',' + book.edition);
  }

  // Method to delete a book by ID using GET
  public deleteData(id: number): Observable<any> {
    return this.http.get<any>(this.url + '?param=delete=' + id); // Using string concatenation for URL
  }

  // Method to get one specific data by name
  public getOneData(name: string): Observable<MyData[]> {
    return this.http.get<MyData[]>(this.url + '?param=search=' + name); // Using string concatenation for URL
  }
}
