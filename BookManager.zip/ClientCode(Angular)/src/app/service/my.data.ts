export class MyData {
    id: number;
    name:string;
    author:string;
    edition:number;
    

    constructor(id:number,name:string, author:string, edition:number) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.edition = edition;
    }

}
